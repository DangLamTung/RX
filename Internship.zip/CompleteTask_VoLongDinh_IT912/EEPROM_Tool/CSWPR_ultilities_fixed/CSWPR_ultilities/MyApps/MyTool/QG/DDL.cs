﻿using System.Configuration;
using RBLib;

namespace MyTool

{
    class DDL : TaskBase
    {
        private string file = string.Empty;

        public DDL() : base()
        {
        }

        public override int ValidateInputData(string taskNameList = "")
        {
            if (!IsMyTask(taskNameList))
            {
                return 0;
            }

            string dataDir = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "OutputDir") + "\\data";
            string bbNumber = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "BBNumber");

            if (!IOMngr.Instance.CheckDDLFile(dataDir, bbNumber, ref file))
            {
                return PrintError(file, "QG_DDL_Hint");
            }

            return 1;
        }

        public override int DoTask(string parentDir, string taskNameList = "")
        {
            if (!IsMyTask(taskNameList))
            {
                return 0;
            }

            if (!CreateDir(parentDir, "QG_DDL_Dir"))
            {
                return -1;
            }

            string error = string.Empty;
            string fileTitle = RBIO.GetFileTitle(file);
            string xlsFile = dir + "\\" + fileTitle + ".xls";

            // Delete old Excel file
            if (RBIO.CheckFileExist(xlsFile))
            {
                if (!RBIO.DeleteFile(xlsFile))
                {
                    Logger.Instance.LogError(this.GetClassName() + " Delete old Excel file failed");
                    return -1;
                }
            }

            RBExcel excel = new RBExcel();

            // Create file DiagnosticDataList_BBNumber.xls
            Logger.Instance.LogInfo(this.GetClassName() + " Create file: " + xlsFile);
            if (!excel.Create(xlsFile, fileTitle, ref error))
            {
                Logger.Instance.LogError(this.GetClassName() + " Create Excel file failed. " + error);
                return -1;
            }

            // Transfer data
            Logger.Instance.LogInfo(this.GetClassName() + " Transfer data from " + file);
            if (!RBExcelHelper.TransferData(file, ConfigurationManager.AppSettings["QG_DDL_Delimiter"], excel, ref error))
            {
                Logger.Instance.LogError(this.GetClassName() + " Transfer data failed. " + error);
                return -1;
            }

           

            // Freeze first row
            Logger.Instance.LogInfo(this.GetClassName() + " Freeze first row...");
            if (!RBExcelHelper.FreezeExcelRow(excel, ConfigurationManager.AppSettings["QG_DDL_Freeze_Row"].Split(';'), ref error))
            {
                Logger.Instance.LogError(this.GetClassName() + " Freeze Excel row failed. " + error);
                return -1;
            }


            

            //Highlight first row
            Logger.Instance.LogInfo(this.GetClassName() + " Bolder Text in the first row...");
            if (!RBExcelHelper.BolderText(excel, ConfigurationManager.AppSettings["QG_DDL_Bolder_Text"].Split(';'), ref error))
            {
                Logger.Instance.LogError(this.GetClassName() + " Bolder Text in the first row failed. " + error);
                return -1;
            }

            

            // AutoFit Columns
            Logger.Instance.LogInfo(this.GetClassName() + " AutoFit Columns...");
            if (!RBExcelHelper.AutoFitColumns(excel, ConfigurationManager.AppSettings["QG_DDL_AutoFit_Text"].Split(';'), ref error))
            {
                Logger.Instance.LogError(this.GetClassName() + " AutoFit Columns failed. " + error);
                return -1;
            }

           
            // Hide columns
            Logger.Instance.LogInfo(this.GetClassName() + " Hide columns...");
            if (!RBExcelHelper.HideExcelColumns(excel, ConfigurationManager.AppSettings["QG_DDL_Hide_Columns"].Split(';'), ref error))
            {
                Logger.Instance.LogError(this.GetClassName() + " Hide Excel columns failed. " + error);
                return -1;

            }

            // Add columns (OK/NotOK, Reviewed by, Comment)
            Logger.Instance.LogInfo(this.GetClassName() + " Add columns...");
            if (!RBExcelHelper.SetRowsValue(excel, 1, ConfigurationManager.AppSettings["QG_DDL_Add_Columns"].Split(';'), ref error))
            {
                Logger.Instance.LogError(this.GetClassName() + " Add Excel columns failed. " + error);
                return -1;
            }

            //Enable filter first row
            Logger.Instance.LogInfo(this.GetClassName() + " Enable filter for the first row...");
            if (!RBExcelHelper.EnableFilter(excel, ConfigurationManager.AppSettings["QG_DDL_Filter_Row"].Split(';'), ref error))
            {
                Logger.Instance.LogError(this.GetClassName() + " Enable filter for the first row failed. " + error);
                return -1;
            }




            // Save file
            Logger.Instance.LogInfo(this.GetClassName() + " Save file...");
            if (!excel.SaveAs(xlsFile))
            {
                Logger.Instance.LogError(this.GetClassName() + " Save Excel file failed");
                return -1;
            }

            excel.Close();
            return 1;
        }
    }
}
