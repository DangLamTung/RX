﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;

namespace RBLib
{
    public class RBExcel
    {
        public Excel.Application xlApp = null;
        public Excel.Workbook xlWorkBook = null;
        public Excel.Worksheet xlWorkSheet = null;
        
        public bool Create(string file, string sheetName,  ref string error)
        {
            try
            {
                xlApp = new Excel.Application();
                if (xlApp == null)
                {
                    error = "Open Excel failed";
                    return false;
                }

                // WorkBook
                xlWorkBook = xlApp.Workbooks.Add(Missing.Value);
                if (xlWorkBook == null)
                {
                    error = "Add Workbook failed";
                    return false;
                }

                // WorkSheet
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
                if (xlWorkSheet == null)
                {
                    error = "Add Worksheet failed";
                    return false;
                }
                xlWorkSheet.Name = sheetName;

                xlWorkBook.SaveAs(file);
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }

            return true;
        }

        public bool Open(string file, string sheetName, ref string error)
        {
            try
            {
                xlApp = new Excel.Application();
                if (xlApp == null)
                {
                    error = "Open Excel failed";
                    return false;
                }

                // WorkBook
                xlWorkBook = xlApp.Workbooks.Open(file);
                if (xlWorkBook == null)
                {
                    error = "Open Workbook failed";
                    return false;
                }

                // WorkSheet
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(sheetName);
                if (xlWorkSheet == null)
                {
                    error = "Open Worksheet failed";
                    return false;
                }
               

            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }

            return true;
        }

       public bool ChangeSheetName(string oldName, string newName, ref string error)
        {
            try
            {
                if (xlApp == null)
                {
                    error = "Excel instance is null";
                    return false;
                }

                // WorkSheet
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(oldName);
                if (xlWorkSheet == null)
                {
                    error = "Worksheet is null";
                    return false;
                }

                xlWorkSheet.Name = newName;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }

            return true;
        }

        public bool CopyWorksheet(string file, string sheetName, ref string error)
        {
            try
            {
                if (xlApp == null)
                {
                    error = "Excel application is null";
                    return false;
                }

                // WorkBook
                Excel.Workbook tmpWorkBook = xlApp.Workbooks.Open(file);
                if (tmpWorkBook == null)
                {
                    error = "Open Workbook failed";
                    return false;
                }

                // WorkSheet
                Excel.Worksheet tmpWorkSheet = (Excel.Worksheet)tmpWorkBook.Worksheets.get_Item(sheetName);
                if (tmpWorkSheet == null)
                {
                    error = "Open Worksheet failed";
                    return false;
                }

                tmpWorkSheet.Copy(xlWorkSheet);
                tmpWorkBook.Close(false);
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }

            return true;
        }


        public bool Save()
        {
            if (xlWorkBook == null)
            {
                return false;
            }

            xlWorkBook.Save();
            return true;
        }

        public bool SaveAs(string file)
        {
            if (xlWorkBook == null)
            {
                return false;
            }

            xlWorkBook.SaveAs(file);
            return true;
        }

        public void Close()
        {
            if (xlApp != null)
            {
                xlApp.Quit();
            }

            // CleanUp
            if (xlWorkSheet != null)
            {
                Marshal.ReleaseComObject(xlWorkSheet);
            }

            if (xlWorkBook != null)
            {
                Marshal.ReleaseComObject(xlWorkBook);
            }

            if (xlApp != null)
            {
                Marshal.ReleaseComObject(xlApp);
            }
        }
    }
}
