﻿using System;

namespace MyApps
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello !!!");
            Console.Write("Press ENTER to exit...");
            Console.ReadLine();
        }
    }
}
