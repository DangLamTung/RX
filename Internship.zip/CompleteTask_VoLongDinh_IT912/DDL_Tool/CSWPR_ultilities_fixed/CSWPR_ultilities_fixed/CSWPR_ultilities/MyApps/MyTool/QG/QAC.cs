﻿using System;
using System.IO;
using System.Configuration;
using RBLib;
using Excel = Microsoft.Office.Interop.Excel;

namespace MyTool
{
    class QAC : TaskBase
    {
        private string file = string.Empty;
        private string zipFile = string.Empty;

        public QAC() : base()
        {
        }

        public override int ValidateInputData(string taskNameList = "")
        {
            if (!IsMyTask(taskNameList))
            {
                return 0;
            }

            string dataDir = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "OutputDir") + "\\data";

            if (!IOMngr.Instance.CheckQACTxtFile(dataDir, ref file))
            {
                return PrintError(file, "QG_QAC_Txt_Hint");
            }

            if (!IOMngr.Instance.CheckQACZipFile(dataDir, ref zipFile))
            {
                return PrintError(zipFile, "QG_QAC_Zip_Hint");
            }

            return 1;
        }

        public override int DoTask(string parentDir, string taskNameList = "")
        {
            if (!IsMyTask(taskNameList))
            {
                return 0;
            }

            if (!base.CreateDir(parentDir, "QG_QAC_Dir"))
            {
                return -1;
            }

            string result = string.Empty, error = string.Empty;
            string bbNumber = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "BBNumber");
            string xlsFile = dir + "\\" + bbNumber + ConfigurationManager.AppSettings["QG_QAC_File"];

            // Copy Zip file
            if (CopyFileWithInfo(dir, zipFile) < 1)
            {
                return -1;
            }

            // Delete old Excel file
            if (RBIO.CheckFileExist(xlsFile))
            {
                if (!RBIO.DeleteFile(xlsFile))
                {
                    Logger.Instance.LogError(this.GetClassName() + " Delete old Excel file failed");
                    return -1;
                }
            }

            RBExcel excel = new RBExcel();

            // Create file BBNumber_QAC_report.xlsx
            Logger.Instance.LogInfo(this.GetClassName() + " Create file: " + xlsFile);
            if (!excel.Create(xlsFile, bbNumber, ref error))
            {
                Logger.Instance.LogError(this.GetClassName() + " Create Excel file failed. " + error);
                return -1;
            }

            // Transfer data
            Logger.Instance.LogInfo(this.GetClassName() + " Transfer data from " + file);
            if (!TransferDataQAC(file, ConfigurationManager.AppSettings["QG_QAC_Delimiter"], excel, ref error))
            {
                Logger.Instance.LogError(this.GetClassName() + " Transfer data failed. " + error);
                return -1;
            }

            // Add columns (OK/NotOK, Reviewed by, Comment)
            Logger.Instance.LogInfo(this.GetClassName() + " Add columns...");
            string[] columns = ConfigurationManager.AppSettings["QG_QAC_Add_Columns"].Split(';');
            if (!RBExcelHelper.SetRowsValue(excel, 5, columns, ref error))
            {
                Logger.Instance.LogError(this.GetClassName() + " Add Excel columns failed. " + error);
                return -1;
            }

            // Verify QAC file
            Logger.Instance.LogInfo(this.GetClassName() + " Verify QAC file...");
            if (!VerifyQACFile(excel, 7, ConfigurationManager.AppSettings["QG_QAC_Verify_Columns"].Split(';'),
                RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "UserName"), ConfigurationManager.AppSettings["QG_QAC_Comment"], ref result, ref error))
            {
                Logger.Instance.LogError(this.GetClassName() + " Verify QAC file failed. " + error);
                return -1;
            }

            if (result != string.Empty)
            {
                Logger.Instance.LogWarning(this.GetClassName() + " There are " + result.Split(',').Length.ToString() + " rows diffrent");
                Logger.Instance.LogWarning(this.GetClassName() + " " + result);
            }

            // Save file
            Logger.Instance.LogInfo(this.GetClassName() + " Save file...");
            if (!excel.SaveAs(xlsFile))
            {
                Logger.Instance.LogError(this.GetClassName() + " Save Excel file failed");
                return -1;
            }

            excel.Close();
            return 1;
        }

        private bool TransferDataQAC(string file, string delimiter, RBExcel excel, ref string error)
        {
            bool res = true;
            StreamReader reader = null;

            try
            {
                int row = 1, column = 1;
                string line = string.Empty;
                reader = new StreamReader(file);

                while ((line = reader.ReadLine()) != null)
                {
                    if (line != string.Empty)
                    {
                        if (line.StartsWith("=="))
                        {
                            string[] arr = line.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                            for (column = 1; column <= arr.Length; column++)
                            {
                                excel.xlWorkSheet.Cells[row, column] = "'" + arr[column - 1].Trim();
                            }
                        }
                        else
                        {
                            string[] arr = line.Split(new string[] { delimiter }, StringSplitOptions.RemoveEmptyEntries);
                            for (column = 1; column <= arr.Length; column++)
                            {
                                excel.xlWorkSheet.Cells[row, column] = arr[column - 1].Trim();
                            }
                        }


                    }

                    row++;
                }
            }
            catch (Exception ex)
            {
                error = ex.Message;
                res = false;
            }
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                }
            }

            return res;
        }

        private bool VerifyQACFile(RBExcel excel, int startRow, string[] verifyColumns, string userName, string comment, ref string result, ref string error)
        {
            try
            {
                bool ret = true;
                result = string.Empty;
                Excel.Range xlRange = excel.xlWorkSheet.UsedRange;

                for (int row = startRow; row <= xlRange.Rows.Count; row++)
                {
                    if (excel.xlWorkSheet.Cells[row, 1].Value2.ToString().StartsWith("=="))
                    {
                        break;
                    }

                    ret = true;
                    foreach (string column in verifyColumns)
                    {
                        if (excel.xlWorkSheet.Cells[row, column].Value2.ToString() != "0")
                        {
                            ret = false;
                            break;
                        }
                    }

                    if (ret)
                    {
                        excel.xlWorkSheet.Cells[row, "L"] = "OK";
                        excel.xlWorkSheet.Cells[row, "M"] = userName;
                        excel.xlWorkSheet.Cells[row, "N"] = comment;
                    }
                    else
                    {
                        if (result == string.Empty)
                        {
                            result = row.ToString();
                        }
                        else
                        {
                            result += ", " + row.ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }

            return true;
        }
    }
}
