﻿using System.Configuration;
using RBLib;

namespace MyTool
{
    public class TaskBase
    {
        public string dir = string.Empty;

        protected TaskBase()
        {
        }

        protected bool CreateDir(string parentDir, string key)
        {
            string tmp = parentDir + "\\" + ConfigurationManager.AppSettings[key];
            if (RBIO.CreateDir(tmp) == true)
            {
                dir = tmp;
                Logger.Instance.LogInfo(this.GetClassName() + " Create directory...OK => " + tmp);
                return true;
            }
            else
            {
                Logger.Instance.LogError(this.GetClassName() + " Create directory...FAILED => " + tmp);
                return false;
            }
        }

        protected bool IsMyTask(string taskNameList)
        {
            if (!taskNameList.Equals("") && !taskNameList.Contains(this.GetType().Name))
            {
                return false;
            }

            return true;
        }

        protected int PrintError(string file, string hint)
        {
            Logger.Instance.LogError(this.GetClassName() + " File not found: " + file);
            Logger.Instance.LogError(this.GetClassName() + " Hint: " + ConfigurationManager.AppSettings[hint]);
            return -1;
        }

        protected int CopyFileWithInfo(string dir, string file)
        {
            Logger.Instance.LogInfo(this.GetClassName() + " Copy file: " + file);
            if (!RBIO.CopyFile(file, dir))
            {
                Logger.Instance.LogError(this.GetClassName() + " Copy file failed");
                return -1;
            }

            return 1;
        }

        public string GetClassName()
        {
            return "[" + this.GetType().Name + "]";
        }

        public virtual int ValidateInputData(string taskNameList = "")
        {
            Logger.Instance.LogWarning(this.GetClassName() + " Coming soon...");
            return -1;
        }

        public virtual int DoTask(string parentDir = "", string taskNameList = "")
        {
            Logger.Instance.LogWarning(this.GetClassName() + " Coming soon...");
            return -1;
        }
    }
}
