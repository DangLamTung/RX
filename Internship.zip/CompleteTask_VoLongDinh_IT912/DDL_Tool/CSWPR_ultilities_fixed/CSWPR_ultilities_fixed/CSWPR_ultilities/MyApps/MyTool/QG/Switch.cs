﻿using System;
using System.Configuration;
using RBLib;
using Excel = Microsoft.Office.Interop.Excel;

namespace MyTool
{
    class Switch : TaskBase
    {
        private string file = string.Empty;

        public Switch() : base()
        {
        }

        public override int ValidateInputData(string taskNameList = "")
        {
            if (!IsMyTask(taskNameList))
            {
                return 0;
            }

            string dataDir = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "OutputDir") + "\\data";
            string bbNumber = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "BBNumber");

            if (!IOMngr.Instance.CheckSwitchFile(dataDir, bbNumber, ref file))
            {
                return PrintError(file, "QG_Switch_Hint");
            }

            return 1;
        }

        public override int DoTask(string parentDir, string taskNameList = "")
        {
            if (!IsMyTask(taskNameList))
            {
                return 0;
            }

            if (!CreateDir(parentDir, "QG_Switch_Dir"))
            {
                return -1;
            }

            // Delete old Excel file
            string xlsFile = dir + "\\" + RBIO.GetFileName(file);
            if (RBIO.CheckFileExist(xlsFile))
            {
                if (!RBIO.DeleteFile(xlsFile))
                {
                    Logger.Instance.LogError(this.GetClassName() + " Delete old Excel file failed");
                    return -1;
                }
            }

            string userName = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "UserName");
            string result = string.Empty;
            string error = string.Empty;

            // Verify Switch file
            Logger.Instance.LogInfo(this.GetClassName() + " Verify Switch file...");
            if (!VerifySwitchFile(userName, ref result, ref error))
            {
                Logger.Instance.LogError(this.GetClassName() + " Verify Switch file failed. " + error);
                return -1;
            }

            if (result != string.Empty)
            {
                Logger.Instance.LogInfo(this.GetClassName() + " There are " + result.Split(',').Length.ToString() + " rows diffrent");
                Logger.Instance.LogInfo(this.GetClassName() + " " + result);
            }

            return 1;
        }

        private bool VerifySwitchFile(string userName, ref string result, ref string error)
        {
            string ratedAt = ConfigurationManager.AppSettings["QG_Switch_Rated_At"];
            string comment = ConfigurationManager.AppSettings["QG_Switch_Comment"];
            string commentOk = ConfigurationManager.AppSettings["QG_Switch_Comment_Ok"];

            RBExcel excel = new RBExcel();

            try
            {
                // Open Excel file
                if (!excel.Open(file, ConfigurationManager.AppSettings["QG_Switch_Sheet_Name"], ref error))
                {
                    error = "Open Excel file failed. Error:" + error;
                    return false;
                }

                string[] arr = ConfigurationManager.AppSettings["QG_Switch_Verify_Column"].Split('=');
                if (arr.Length != 2)
                {
                    error = "Wrong value format. Check setting file. (Ex: Column=Value)";
                    return false;
                }

                // Verify and update comment
                Excel.Range xlRange = excel.xlWorkSheet.UsedRange;
                for (int row = 13; row <= xlRange.Rows.Count; row++)
                {
                    if (excel.xlWorkSheet.Cells[row, arr[0]].Value2.ToString() == arr[1])
                    {
                        excel.xlWorkSheet.Cells[row, "O"] = commentOk;
                        excel.xlWorkSheet.Cells[row, "P"] = ratedAt;
                        excel.xlWorkSheet.Cells[row, "Q"] = userName;
                        excel.xlWorkSheet.Cells[row, "R"] = comment;
                    }
                    else
                    {
                        if (result == string.Empty)
                        {
                            result = row.ToString();
                        }
                        else
                        {
                            result += ", " + row.ToString();
                        }
                    }
                }

                // Save
                if (!excel.SaveAs(dir + "\\" + RBIO.GetFileName(file)))
                {
                    error = "Save Excel failed";
                    return false;
                }
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
            finally
            {
                excel.Close();
            }

            return true;
        }
    }
}
