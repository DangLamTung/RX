﻿using System.Collections.Generic;

namespace MyTool
{
    public class QG : TaskBase
    {
        private List<TaskBase> workers = null;

        public QG() : base()
        {
            workers = new List<TaskBase>();
            workers.Add(new DDL());
            workers.Add(new QAC());
            workers.Add(new LockedObjects());
            workers.Add(new EEPROM());
            workers.Add(new DumpCheck());
            workers.Add(new Errata());
            workers.Add(new ErrorLog());
            workers.Add(new LCModel());
            workers.Add(new MemTrace());
            workers.Add(new Switch());
        }

        public override int ValidateInputData(string taskNameList = "")
        {
            int res = 0;
            foreach (TaskBase worker in workers)
            {
                res = worker.ValidateInputData(taskNameList);
                if (res < 0)
                {
                    Logger.Instance.LogError(worker.GetClassName() + " Checking input data...FAILED");
                    return res;
                }
                else if (res > 0)
                {
                    Logger.Instance.LogInfo(worker.GetClassName() + " Checking input data...OK");
                }
            }

            return res;
        }

        public override int DoTask(string parentDir, string taskNameList = "")
        {
            if (!CreateDir(parentDir, "QG_Dir"))
            {
                return -1;
            }
            Logger.Instance.LogInfo(this.GetClassName() + " Do task...OK\r\n");

            int res = 0;
            foreach (TaskBase worker in workers)
            {
                res = worker.DoTask(dir, taskNameList);
                if (res < 0)
                {
                    Logger.Instance.LogError(worker.GetClassName() + " Do task...FAILED");
                    return res;
                }
                else if (res > 0)
                {
                    Logger.Instance.LogInfo(worker.GetClassName() + " Do task...OK\r\n");
                }
            }

            return res;
        }
    }
}
