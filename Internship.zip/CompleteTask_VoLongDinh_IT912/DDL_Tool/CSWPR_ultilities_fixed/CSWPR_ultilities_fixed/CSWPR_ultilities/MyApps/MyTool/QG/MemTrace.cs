﻿using System.Configuration;
using RBLib;

namespace MyTool
{
    class MemTrace : TaskBase
    {
        private string file = string.Empty;
        private string fileRuntime = string.Empty;
        private string fileAnaStack = string.Empty;

        public MemTrace() : base()
        {
        }

        public override int ValidateInputData(string taskNameList = "")
        {
            if (!IsMyTask(taskNameList))
            {
                return 0;
            }

            string dataDir = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "OutputDir") + "\\data";
            string bbNumber = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "BBNumber");

            if (!IOMngr.Instance.CheckMemTraceFile(dataDir, bbNumber, ref file))
            {
                return PrintError(file, "QG_MemTrace_Hint");
            }

            if (!IOMngr.Instance.CheckMemTraceRuntimeFile(dataDir, bbNumber, ref fileRuntime))
            {
                return PrintError(fileRuntime, "QG_MemTrace_Runtime_Hint");
            }

            if (!IOMngr.Instance.CheckMemTraceAnaStackFile(dataDir, bbNumber, ref fileAnaStack))
            {
                return PrintError(fileAnaStack, "QG_MemTrace_AnaStack_Hint");
            }

            return 1;
        }

        public override int DoTask(string parentDir, string taskNameList = "")
        {
            if (!IsMyTask(taskNameList))
            {
                return 0;
            }

            if (!CreateDir(parentDir, "QG_MemTrace_Dir"))
            {
                return -1;
            }

            // Copy file
            if (CopyFileWithInfo(dir, file) < 1 || CopyFileWithInfo(dir, fileRuntime) < 1 || CopyFileWithInfo(dir, fileAnaStack) < 1)
            {
                return -1;
            }

            return 1;
        }
    }
}
