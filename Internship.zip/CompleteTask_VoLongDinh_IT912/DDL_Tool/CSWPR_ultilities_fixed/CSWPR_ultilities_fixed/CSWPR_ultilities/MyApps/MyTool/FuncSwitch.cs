﻿using System;
using System.IO;
using System.Collections.Generic;
using RBLib;

namespace MyTool
{
    public class FuncSwitch : TaskBase
    {
        private string file = string.Empty;
        Dictionary<string, string> variables = null;
        Dictionary<string, string> specialVariables = null;
        List<string> directories = null;

        public FuncSwitch() : base()
        {
            variables = new Dictionary<string, string>();
            specialVariables = new Dictionary<string, string>();
            directories = new List<string>();
        }

        public override int ValidateInputData(string taskNameList = "")
        {
            // Checking project directory
            string tmp = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "ProjectDir");
            if (!RBIO.CheckDirExist(tmp))
            {
                Logger.Instance.LogError(this.GetClassName() + " Checking project directory...FAILED => Directory not found: " + tmp + ". Update the Config.ini file");
                return -1;
            }
            this.dir = tmp;
            Logger.Instance.LogInfo(this.GetClassName() + " Checking project directory...OK => " + dir);

            // Checking FuncSwitch.txt file
            tmp = IOMngr.Instance.GetFuncSwitchFile();
            if (!RBIO.CheckFileExist(tmp))
            {
                Logger.Instance.LogError(this.GetClassName() + " Checking FuncSwitch.txt file...FAILED => File not found");
                return -1;
            }
            file = tmp;
            Logger.Instance.LogInfo(this.GetClassName() + " Checking FuncSwitch.txt file...OK");

            // Reading FuncSwitch.txt file
            if (!ReadFuncSwitchFile())
            {
                return -1;
            }
            Logger.Instance.LogInfo(this.GetClassName() + " Reading FuncSwitch.txt file...OK");

            // Print data
            PrintData();

            return 1;
        }

        public override int DoTask(string parentDir = "", string taskNameList = "")
        {
            Logger.Instance.LogInfo(this.GetClassName() + " Special Variables");
            GetSpecialValues(specialVariables);

            Logger.Instance.Log("");
            Logger.Instance.LogInfo(this.GetClassName() + " Variables");
            Dictionary<string, string> vars = new Dictionary<string, string>(variables);
            foreach (string curDir in directories)
            {
                GetValuesInDir(curDir, ref vars);
            }

            if (vars.Count > 0)
            {
                Logger.Instance.Log("");
                Logger.Instance.LogWarning(this.GetClassName() + " The following variables are not found:");
                foreach (KeyValuePair<string, string> entry in vars)
                {
                    Logger.Instance.Log("\t" + entry.Value);
                }
            }
            
            return 1;
        }

        private bool ReadFuncSwitchFile()
        {
            variables.Clear();
            specialVariables.Clear();
            directories.Clear();

            try
            {
                string tmp = string.Empty;
                string line = string.Empty;
                StreamReader reader = new StreamReader(file);

                while ((line = reader.ReadLine()) != null)
                {
                    if (line == string.Empty)
                    {
                        continue;
                    }

                    if (line.StartsWith("\\"))
                    {
                        tmp = dir + line;
                        if (!RBIO.CheckDirExist(tmp))
                        {
                            Logger.Instance.LogError(this.GetClassName() + " Directory not found: " + tmp);
                            return false;
                        }

                        directories.Add(tmp);
                    }
                    else
                    {
                        string[] arr = line.Split(new string[] { "\t" }, StringSplitOptions.RemoveEmptyEntries);
                        if (arr.Length != 2)
                        {
                            Logger.Instance.LogError(this.GetClassName() + " Parser failed. line: " + line);
                            return false;
                        }

                        if (line.Contains("\\"))
                        {
                            specialVariables.Add(arr[1], line);
                        }
                        else
                        {
                            variables.Add(arr[1], line);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                Logger.Instance.LogException(this.GetClassName() + " Exception: " + ex.Message);
                return false;
            }

            return true;
        }

        private void PrintData()
        {
            Logger.Instance.Log("\r\nDirectories: " + directories.Count.ToString());
            foreach (string tmp in directories)
            {
                Logger.Instance.Log("\t" + tmp.Replace(dir, "ProjectDir"));
            }

            Logger.Instance.Log("\r\nSpecial Variables: " + specialVariables.Count.ToString());
            foreach (KeyValuePair<string, string> entry in specialVariables)
            {
                Logger.Instance.Log("\t" + entry.Value);
            }

            Logger.Instance.Log("\r\nVariables: " + variables.Count.ToString());
            foreach (KeyValuePair<string, string> entry in variables)
            {
                Logger.Instance.Log("\t" + entry.Value);
            }
        }

        private void GetSpecialValues(Dictionary<string, string> vars)
        {
            foreach (KeyValuePair<string, string> entry in vars)
            {
                string[] arr = entry.Value.Split(new string[] { "\t" }, StringSplitOptions.RemoveEmptyEntries);
                if (arr.Length >= 2)
                {
                    if (RBIO.CheckDirExist(dir + "\\" + arr[0]))
                    {
                        Logger.Instance.Log("\t" + entry.Value.Trim() + "\t\tExist");
                    }
                    else
                    {
                        Logger.Instance.Log("\t" + entry.Value.Trim() + "\t\tNot Exist");
                    }
                }
                else
                {
                    Logger.Instance.LogError(this.GetClassName() + " Parser failed");
                }
            }
        }

        private void GetValuesInDir(string curDir, ref Dictionary<string, string> vars)
        {
            try
            {
                string[] files = RBIO.GetFiles(curDir, "*.h");
                foreach (string file in files)
                {
                    GetValuesInFile(file, ref vars);
                }

                string[] dirs = RBIO.GetDirectories(curDir);
                {
                    foreach (string dir in dirs)
                    {
                        GetValuesInDir(dir, ref vars);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Instance.LogException(this.GetClassName() + " Exception: " + ex.Message);
            }
        }

        private void GetValuesInFile(string file, ref Dictionary<string, string> vars)
        {
            string[] arr = null;
            string tab2 = "\t\t";
            string tab6 = "\t\t\t\t\t\t";

            int index = 0;
            string line = string.Empty;
            StreamReader reader = new StreamReader(file);
            while ((line = reader.ReadLine()) != null)
            {
                index++;

                if (line == string.Empty)
                {
                    continue;
                }

                if (line.Trim().StartsWith("#if") && !line.Trim().StartsWith("#ifdef"))
                {
                    bool ifFound = false;
                    string ifLine = line;

                    while ((line = reader.ReadLine()) != null)
                    {
                        index++;

                        if (line == string.Empty)
                        {
                            continue;
                        }

                        if (line.Trim().StartsWith("#define"))
                        {
                            arr = line.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                            if (arr.Length >= 3)
                            {
                                if (variables.ContainsKey(arr[1]))
                                {
                                    Logger.Instance.Log("\t" + variables[arr[1]].Trim() + tab2 + file.Replace(dir, "ProjectDir") + "   " + index.ToString());
                                    Logger.Instance.Log(tab6 + ifLine);
                                    Logger.Instance.Log(tab6 + line);

                                    while ((line = reader.ReadLine()) != null)
                                    {
                                        index++;

                                        if (line == string.Empty || !line.Trim().StartsWith("#"))
                                        {
                                            continue;
                                        }

                                        Logger.Instance.Log(tab6 + line.Trim());
                                        if (line.Trim().StartsWith("#endif"))
                                        {
                                            ifFound = true;
                                            break;
                                        }
                                    }

                                    vars.Remove(arr[1]);
                                }
                                else
                                {
                                    break;
                                }
                            }
                        }

                        if (ifFound)
                        {
                            break;
                        }
                    }
                }
                else if (line.Trim().StartsWith("#define"))
                {
                    arr = line.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                    if (arr.Length >= 3)
                    {
                        if (variables.ContainsKey(arr[1]))
                        {
                            if (arr.Length >= 5)
                            {
                                Logger.Instance.Log("\t" + variables[arr[1]].Trim() + tab2 + arr[2].Trim() + " " + arr[3].Trim() + " " + arr[4].Trim() + tab2 + file.Replace(dir, "ProjectDir") + "   " + index.ToString());
                            }
                            else
                            {
                                Logger.Instance.Log("\t" + variables[arr[1]].Trim() + tab2 + arr[2].Trim() + tab2 + file.Replace(dir, "ProjectDir") + "   " + index.ToString());
                            }

                            vars.Remove(arr[1]);
                        }
                    }
                }
            }
        }
    }
}
