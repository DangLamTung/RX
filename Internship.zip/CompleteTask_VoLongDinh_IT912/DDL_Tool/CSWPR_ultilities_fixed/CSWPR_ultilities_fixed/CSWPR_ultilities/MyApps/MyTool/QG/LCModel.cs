﻿using System.Configuration;
using RBLib;

namespace MyTool
{
    class LCModel : TaskBase
    {
        private string file = string.Empty;

        public LCModel() : base()
        {
        }

        public override int ValidateInputData(string taskNameList = "")
        {
            if (!IsMyTask(taskNameList))
            {
                return 0;
            }

            string dataDir = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "OutputDir") + "\\data";

            if (!IOMngr.Instance.CheckLCModelChecklistFile(dataDir, ref file))
            {
                return PrintError(file, "QG_LCModel_Hint");
            }

            return 1;
        }

        public override int DoTask(string parentDir, string taskNameList = "")
        {
            if (!IsMyTask(taskNameList))
            {
                return 0;
            }

            if (!CreateDir(parentDir, "QG_LCModel_Dir"))
            {
                return -1;
            }

            if (CopyFileWithInfo(dir, file) < 1)
            {
                return -1;
            }

            return 1;
        }
    }
}
