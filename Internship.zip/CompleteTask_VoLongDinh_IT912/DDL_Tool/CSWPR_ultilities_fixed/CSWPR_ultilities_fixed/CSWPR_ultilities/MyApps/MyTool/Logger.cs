﻿namespace MyTool
{
    class Logger
    {
        #region Singleton

        private Logger() { }

        private static Logger instance;
        public static Logger Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Logger();
                }

                return instance;
            }
        }

        #endregion

        private FormMain formMain = null;
        public void SetFormMain(FormMain form)
        {
            formMain = form;
        }

        public void Log(string message)
        {
            if (formMain != null)
            {
                formMain.WriteConsole(message);
            }
        }

        public void LogInfo(string message)
        {
            if (formMain != null)
            {
                formMain.WriteConsole("[INFO]\t" + message);
            }
        }

        public void LogWarning(string message)
        {
            if (formMain != null)
            {
                formMain.WriteConsole("[WAR]\t" + message);
            }
        }

        public void LogError(string message)
        {
            if (formMain != null)
            {
                formMain.WriteConsole("[ERR]\t" + message);
            }
        }

        public void LogException(string message)
        {
            if (formMain != null)
            {
                formMain.WriteConsole("[EXPT]\t" + message);
            }
        }
    }
}
