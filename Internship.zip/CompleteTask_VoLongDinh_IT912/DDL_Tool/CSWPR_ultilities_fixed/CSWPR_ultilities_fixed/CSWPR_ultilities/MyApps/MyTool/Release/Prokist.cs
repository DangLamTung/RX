﻿using System.Configuration;

namespace MyTool
{
    class Prokist : TaskBase
    {
        private string file = string.Empty;

        public Prokist() : base()
        {
        }

        public override int ValidateInputData(string taskNameList = "")
        {
            if (!IsMyTask(taskNameList))
            {
                return 0;
            }

            return 1;
        }

        public override int DoTask(string parentDir, string taskNameList = "")
        {
            if (!IsMyTask(taskNameList))
            {
                return 0;
            }

            if (!CreateDir(parentDir, "Release_Prokist_Dir"))
            {
                return -1;
            }

            Logger.Instance.LogInfo(this.GetClassName() + " Hint: " + ConfigurationManager.AppSettings["Release_Prokist_Hint"]);
            return 1;
        }
    }
}
