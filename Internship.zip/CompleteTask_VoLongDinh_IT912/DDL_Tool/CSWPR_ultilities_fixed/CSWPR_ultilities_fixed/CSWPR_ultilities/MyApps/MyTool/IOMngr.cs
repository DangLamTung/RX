﻿using System.IO;
using RBLib;

namespace MyTool
{
    class IOMngr
    {
        #region Singleton

        private IOMngr() { }

        private static IOMngr instance;
        public static IOMngr Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new IOMngr();
                }

                return instance;
            }
        }

        #endregion

        public string GetConfigFile()
        {
            return Directory.GetCurrentDirectory() + "\\Config.ini";
        }

        public string GetFuncSwitchFile()
        {
            return Directory.GetCurrentDirectory() + "\\FuncSwitch.txt";
        }

        #region QG

        public bool CheckDDLFile(string dir, string bbNumber, ref string file)
        {
            file = dir + "\\DiagnosticDataList_" + bbNumber + ".csv";
            return RBIO.CheckFileExist(file);
        }

        public bool CheckQACTxtFile(string dir, ref string file)
        {
            file = dir + "\\WarningSummaryReport.txt";
            return RBIO.CheckFileExist(file);
        }

        public bool CheckQACZipFile(string dir, ref string file)
        {
            file = dir + "\\CC_Codingrules_Project.zip";
            return RBIO.CheckFileExist(file);
        }

        public bool CheckLockedObjectsFile(string dir, ref string file)
        {
            file = "Report_Delta_Lockedobjects_x.y.xls";

            string[] files = RBIO.GetFiles(dir);
            foreach (string tmp in files)
            {
                if (RBIO.GetFileTitle(tmp).StartsWith("Report_Delta_Lockedobjects_"))
                {
                    file = tmp;
                    return true;
                }
            }

            return false;
        }

        public bool CheckEEPROMcntFile(string dir, string bbNumber, ref string file)
        {
            file = "1267SBBNumber_P_SC_00.CNT";

            string[] files = RBIO.GetFiles(dir);
            foreach (string tmp in files)
            {
                if (RBIO.GetFileName(tmp).Contains(bbNumber.Substring(2, bbNumber.Length - 2)) && tmp.EndsWith(".CNT"))
                {
                    file = tmp;
                    return true;
                }
            }

            return false;
        }

        public bool CheckEEPROMspecFile(string dir, string bbNumber, ref string file)
        {
            file = "EEPROM_Spec_BBNumber_BSSxy.xlsx";

            string[] files = RBIO.GetFiles(dir);
            foreach (string tmp in files)
            {
                if (RBIO.GetFileTitle(tmp).StartsWith("EEPROM_Spec_" + bbNumber))
                {
                    file = tmp;
                    return true;
                }
            }

            return false;
        }

        public bool CheckEEPROMdumpFile(string dir, string bbNumber, ref string file)
        {
            file = "Dump_check_12679BBNumber_00_CSW.xlsx";

            string[] files = RBIO.GetFiles(dir);
            foreach (string tmp in files)
            {
                if (RBIO.GetFileTitle(tmp).StartsWith("Dump_check_") && RBIO.GetFileTitle(tmp).Contains(bbNumber.Substring(2, bbNumber.Length - 2)) && tmp.EndsWith(".xlsx"))
                {
                    file = tmp;
                    return true;
                }
            }

            return false;
        }

        public bool CheckErrorLogFile(string dir, ref string file)
        {
            file = "Issue_Log_ProjectName_Vx.y.xls";

            string[] files = RBIO.GetFiles(dir);
            foreach (string tmp in files)
            {
                if (RBIO.GetFileTitle(tmp).StartsWith("Issue_Log_") && tmp.EndsWith(".xls"))
                {
                    file = tmp;
                    return true;
                }
            }

            return false;
        }

        public bool CheckLCModelChecklistFile(string dir, ref string file)
        {
            file = "LC_model_ProjectName_Checklist.xls";

            string[] files = RBIO.GetFiles(dir);
            foreach (string tmp in files)
            {
                if (RBIO.GetFileTitle(tmp).StartsWith("LC_model_") && tmp.EndsWith("_Checklist.xls"))
                {
                    file = tmp;
                    return true;
                }
            }

            return false;
        }

        public bool CheckMemTraceFile(string dir, string bbNumber, ref string file)
        {
            file = "ProjectName_MemTrace_BBNumber_BSSxy.xls";

            string[] files = RBIO.GetFiles(dir);
            foreach (string tmp in files)
            {
                if (RBIO.GetFileTitle(tmp).Contains("_MemTrace_" + bbNumber) && tmp.EndsWith(".xls"))
                {
                    file = tmp;
                    return true;
                }
            }

            return false;
        }

        public bool CheckMemTraceRuntimeFile(string dir, string bbNumber, ref string file)
        {
            file = "ABSx.yMz_RUNTIME_JITTER_BBNumber_Vx.y.xls";

            string[] files = RBIO.GetFiles(dir);
            foreach (string tmp in files)
            {
                if (RBIO.GetFileTitle(tmp).Contains("_RUNTIME_JITTER_" + bbNumber) && tmp.EndsWith(".xls"))
                {
                    file = tmp;
                    return true;
                }
            }

            return false;
        }

        public bool CheckMemTraceAnaStackFile(string dir, string bbNumber, ref string file)
        {
            file = "PRJ_AnaStack_BBNumber_Vxxyy_ECD_CSW.txt";

            string[] files = RBIO.GetFiles(dir);
            foreach (string tmp in files)
            {
                if (RBIO.GetFileTitle(tmp).StartsWith("PRJ_AnaStack_" + bbNumber) && tmp.EndsWith(".txt"))
                {
                    file = tmp;
                    return true;
                }
            }

            return false;
        }

        public bool CheckSwitchFile(string dir, string bbNumber, ref string file)
        {
            file = "OldBBNumber_Vxxxx__NewBBNumber_Vyyyy.xlt";

            string[] files = RBIO.GetFiles(dir);
            foreach (string tmp in files)
            {
                if (RBIO.GetFileTitle(tmp).Contains("__" + bbNumber + "_") && tmp.EndsWith(".xlt"))
                {
                    file = tmp;
                    return true;
                }
            }

            return false;
        }

        #endregion

        #region Release

        public bool CheckAppContainerFile(string dir, string bbNumber, ref string file)
        {
            file = "ApplContainer_BBNumber_Vxxyy_ECD_CSW.appl.zip";

            string[] files = RBIO.GetFiles(dir);
            foreach (string tmp in files)
            {
                if (RBIO.GetFileTitle(tmp).StartsWith("ApplContainer_" + bbNumber) &&  tmp.EndsWith(".appl.zip"))
                {
                    file = tmp;
                    return true;
                }
            }

            return false;
        }

        public bool CheckCSWHEXFile(string dir, string bbNumber, ref string file)
        {
            file = "PRJ_HexFile_BBNumber_Vxxyy_ECD_CSW.hex";

            string[] files = RBIO.GetFiles(dir);
            foreach (string tmp in files)
            {
                if (RBIO.GetFileTitle(tmp).StartsWith("PRJ_HexFile_" + bbNumber) && tmp.EndsWith(".hex"))
                {
                    file = tmp;
                    return true;
                }
            }

            return false;
        }

        public bool CheckLCModelFile(string dir, string bbNumber, ref string file)
        {
            file = "1267LBBNumber_P_LCM_NG7_00.eep";

            string title = string.Empty;
            string[] files = RBIO.GetFiles(dir);
            foreach (string tmp in files)
            {
                title = RBIO.GetFileTitle(tmp);
                if (title.StartsWith("1267") && title.Contains(bbNumber.Substring(2, bbNumber.Length - 2)) && title.Contains("NG7") && tmp.EndsWith(".eep"))
                {
                    file = tmp;
                    return true;
                }
            }

            return false;
        }

        public bool CheckLCModelEMUFile(string dir, string bbNumber, ref string file)
        {
            file = "1267LBBNumber_EMU_LCM_00.eep";

            string title = string.Empty;
            string[] files = RBIO.GetFiles(dir);
            foreach (string tmp in files)
            {
                title = RBIO.GetFileTitle(tmp);
                if (title.StartsWith("1267") && title.Contains(bbNumber.Substring(2, bbNumber.Length - 2)) && title.Contains("EMU") && tmp.EndsWith(".eep"))
                {
                    file = tmp;
                    return true;
                }
            }

            return false;
        }

        public bool CheckTKWinXFile(string dir, string bbNumber, ref string file)
        {
            file = "BBNumber_Vxxyy.zip";

            string[] files = RBIO.GetFiles(dir);
            foreach (string tmp in files)
            {
                if (RBIO.GetFileTitle(tmp).StartsWith(bbNumber + "_") && tmp.EndsWith(".zip"))
                {
                    file = tmp;
                    return true;
                }
            }

            return false;
        }

        public bool CheckFWLFile(string dir, string bbNumber, ref string file)
        {
            file = dir + "\\TKWINX_FAILUREMEMORYDESCRIPTION_" + bbNumber + ".XML";
            return RBIO.CheckFileExist(file);
        }

        public bool CheckODXFile(string dir, ref string file)
        {
            file = dir + "\\RBDIAGCOMPARAMSPEC_MCPLATFORM.ODX";
            return RBIO.CheckFileExist(file);
        }

        #endregion
    }
}
