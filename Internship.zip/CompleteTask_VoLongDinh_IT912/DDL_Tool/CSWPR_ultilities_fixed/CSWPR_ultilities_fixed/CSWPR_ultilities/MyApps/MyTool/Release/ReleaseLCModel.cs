﻿using RBLib;

namespace MyTool
{
    class ReleaseLCModel : TaskBase
    {
        private string file = string.Empty;
        private string fileEMU = string.Empty;

        public ReleaseLCModel() : base()
        {
        }

        public override int ValidateInputData(string taskNameList = "")
        {
            if (!IsMyTask(taskNameList))
            {
                return 0;
            }

            string dataDir = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "OutputDir") + "\\data";
            string bbNumber = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "BBNumber");

            if (!IOMngr.Instance.CheckLCModelFile(dataDir, bbNumber, ref file))
            {
                return PrintError(file, "Release_LCModel_Hint");
            }

            if (!IOMngr.Instance.CheckLCModelEMUFile(dataDir, bbNumber, ref fileEMU))
            {
                return PrintError(file, "Release_LCModel_Hint");
            }

            return 1;
        }

        public override int DoTask(string parentDir, string taskNameList = "")
        {
            if (!IsMyTask(taskNameList))
            {
                return 0;
            }

            if (!CreateDir(parentDir, "Release_LCModel_Dir"))
            {
                return -1;
            }

            // Copy file
            if (CopyFileWithInfo(dir, file) < 1 || CopyFileWithInfo(dir, fileEMU) < 1)
            {
                return -1;
            }

            return 1;
        }
    }
}
