﻿using System.Configuration;
using RBLib;

namespace MyTool
{
    class ErrorLog : TaskBase
    {
        private string file = string.Empty;

        public ErrorLog() : base()
        {
        }

        public override int ValidateInputData(string taskNameList = "")
        {
            if (!IsMyTask(taskNameList))
            {
                return 0;
            }

            string dataDir = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "OutputDir") + "\\data";

            if (!IOMngr.Instance.CheckErrorLogFile(dataDir, ref file))
            {
                return PrintError(file, "QG_ErrorLog_Hint");
            }

            return 1;
        }

        public override int DoTask(string parentDir, string taskNameList = "")
        {
            if (!IsMyTask(taskNameList))
            {
                return 0;
            }

            if (!CreateDir(parentDir, "QG_ErrorLog_Dir"))
            {
                return -1;
            }

            // Copy file
            if (CopyFileWithInfo(dir, file) < 1)
            {
                return -1;
            }

            return 1;
        }
    }
}
