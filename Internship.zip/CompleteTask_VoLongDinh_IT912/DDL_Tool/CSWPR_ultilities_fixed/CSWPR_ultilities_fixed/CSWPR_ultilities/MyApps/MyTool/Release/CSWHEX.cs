﻿using RBLib;

namespace MyTool
{
    class CSWHEX : TaskBase
    {
        private string file = string.Empty;

        public CSWHEX() : base()
        {
        }

        public override int ValidateInputData(string taskNameList = "")
        {
            if (!IsMyTask(taskNameList))
            {
                return 0;
            }

            string dataDir = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "OutputDir") + "\\data";
            string bbNumber = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "BBNumber");

            if (!IOMngr.Instance.CheckCSWHEXFile(dataDir, bbNumber, ref file))
            {
                return PrintError(file, "Release_CSW_HEX_Hint");
            }

            return 1;
        }

        public override int DoTask(string parentDir, string taskNameList = "")
        {
            if (!IsMyTask(taskNameList))
            {
                return 0;
            }

            if (!CreateDir(parentDir, "Release_CSW_HEX_Dir"))
            {
                return -1;
            }

            // Copy file
            if (CopyFileWithInfo(dir, file) < 1)
            {
                return -1;
            }

            return 1;
        }
    }
}
