﻿using System;
using System.Configuration;
using RBLib;
using Excel = Microsoft.Office.Interop.Excel;
using System.Drawing;

namespace MyTool
{
    class EEPROM : TaskBase
    {
        private string fileCNT = string.Empty;
        private string file = string.Empty;

        public EEPROM() : base()
        {
        }

        public override int ValidateInputData(string taskNameList = "")
        {
            if (!IsMyTask(taskNameList))
            {
                return 0;
            }

            string dataDir = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "OutputDir") + "\\data";
            string bbNumber = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "BBNumber");

            if (!IOMngr.Instance.CheckEEPROMcntFile(dataDir, bbNumber, ref fileCNT))
            {
                return PrintError(fileCNT, "QG_EEPROM_Hint");
            }

            if (!IOMngr.Instance.CheckEEPROMspecFile(dataDir, bbNumber, ref file))
            {
                return PrintError(file, "QG_EEPROM_Hint");
            }

            return 1;
        }

        public override int DoTask(string parentDir, string taskNameList = "")
        {
            if (!IsMyTask(taskNameList))
            {
                return 0;
            }
            
            if (!CreateDir(parentDir, "QG_EEPROM_CNT_Dir"))
            {
                return -1;
            }

            // Copy file
            if (CopyFileWithInfo(dir, fileCNT) < 1)
            {
                return -1;
            }

            if (!CreateDir(parentDir, "QG_EEPROM_Spec_Dir"))
            {
                return -1;
            }

            // Delete old Excel file
            string xlsFile = dir + "\\" + RBIO.GetFileName(file);
            if (RBIO.CheckFileExist(xlsFile))
            {
                if (!RBIO.DeleteFile(xlsFile))
                {
                    Logger.Instance.LogError(this.GetClassName() + " Delete old Excel file failed");
                    return -1;
                }
            }

            string error = string.Empty;
            string sheetName = ConfigurationManager.AppSettings["QG_EEPROM_Sheet_Name"];
            string mergeRange = ConfigurationManager.AppSettings["QG_EEPROM_Merge_Ranges"];

            RBExcel excel = new RBExcel();

            // Open file EEPROM_Spec_BBNumber_BSSxy.xlsx
            Logger.Instance.LogInfo(this.GetClassName() + " Open file: " + file);
            if (!excel.Open(file, sheetName, ref error))
            {
                Logger.Instance.LogError(this.GetClassName() + " Create Excel file failed. " + error);
                return -1;
            }

            // Delete column
            Logger.Instance.LogInfo(this.GetClassName() + " Delete columns...");
            string[] columns = ConfigurationManager.AppSettings["QG_EEPROM_Delete_Columns"].Split(';');
            if (!RBExcelHelper.DeleteExcelColumns(excel, columns, ref error))
            {
                Logger.Instance.LogError(this.GetClassName() + " Delete Excel columns failed. " + error);
                return -1;
            }

            // Add columns (Usage, OK/NotOK, Reviewed by, Comment)
            Logger.Instance.LogInfo(this.GetClassName() + " Add columns...");
            columns = ConfigurationManager.AppSettings["QG_EEPROM_Add_Columns"].Split(';');
            if (!RBExcelHelper.SetRowsValue(excel, 18, columns, ref error, 3))
            {
                Logger.Instance.LogError(this.GetClassName() + " Add Excel columns failed. " + error);
                return -1;
            }

            // Prepare EEPROM file
            Logger.Instance.LogInfo(this.GetClassName() + " Prepare EEPROM file...");
            if (!PrepareEEPROMFile(excel, 18, mergeRange, ref error))
            {
                Logger.Instance.LogError(this.GetClassName() + " Prepare EEPROM file failed. " + error);
                return -1;
            }
            
            // Verify EEPROM file
            Logger.Instance.LogInfo(this.GetClassName() + " Verify EEPROM file...");
            if (!VerifyEEPROMFile(excel, 18, ref error))
            {
                Logger.Instance.LogError(this.GetClassName() + " Verify EEPROM file failed. " + error);
                return -1;
            }

            // Save file
            Logger.Instance.LogInfo(this.GetClassName() + " Save file...");
            if (!excel.SaveAs(xlsFile))
            {
                Logger.Instance.LogError(this.GetClassName() + " Save Excel file failed");
                return -1;
            }

            excel.Close();
            return 1;
        }
        
        private bool PrepareEEPROMFile(RBExcel excel, int row, string range, ref string error)
        {
            try
            {
                // Get info
                string tmp, basedContainer = string.Empty, currentContainer = string.Empty;
                for (int i = 1; i < row; i++)
                {
                    if (excel.xlWorkSheet.Cells[i, 1].Value2 != null)
                    {
                        tmp = excel.xlWorkSheet.Cells[i, 1].Value2.ToString();
                        if (tmp.StartsWith("Main Container File"))
                        {
                            basedContainer = "Based container\r\n" + tmp.Substring(tmp.LastIndexOf('\\') + 1, tmp.Length - tmp.LastIndexOf('\\') - 1);
                        }

                        if (tmp.StartsWith("Compare Container File"))
                        {
                            currentContainer = "Current container\r\n" + tmp.Substring(tmp.LastIndexOf('\\') + 1, tmp.Length - tmp.LastIndexOf('\\') - 1);
                        }
                    }

                    if (basedContainer != string.Empty && currentContainer != string.Empty)
                    {
                        break;
                    }
                }

                // Insert row
                excel.xlWorkSheet.Rows[row].Insert();

                // Merge cells
                string[] ranges = range.Split(new string[] { ";" }, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < ranges.Length; i++)
                {
                    excel.xlWorkSheet.get_Range(ranges[i]).Merge();
                    excel.xlWorkSheet.get_Range(ranges[i]).Cells.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                    excel.xlWorkSheet.get_Range(ranges[i]).Cells.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
                }

                excel.xlWorkSheet.Cells[row - 1, "C"] = basedContainer;
                excel.xlWorkSheet.Cells[row - 1, "G"] = currentContainer;

                // TODO: Update CustPartNo & ProcessData
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }

            return true;
        }
        
        private bool VerifyEEPROMFile(RBExcel excel, int row, ref string error)
        {
            string userName = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "UserName");
            string commentOk = ConfigurationManager.AppSettings["QG_EEPROM_Comment_Ok"];
            string commentBBno = ConfigurationManager.AppSettings["QG_EEPROM_Comment_BBno"];
            commentBBno = commentBBno.Replace("ProjectName", RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "ProjectName"));
            commentBBno = commentBBno.Replace("BBNumber", RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "BBNumber"));
            string commentCSIS = ConfigurationManager.AppSettings["QG_EEPROM_Comment_CSIS"].Replace("xxxxxx", RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "CSIS"));
            string commentCustPartNo = ConfigurationManager.AppSettings["QG_EEPROM_Comment_CustPartNo"].Replace("xxxxyyyy", RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "CSCRM"));
            string commentBarcodeHU = ConfigurationManager.AppSettings["QG_EEPROM_Comment_BarcodeHU"];

            try
            {
                // Verify and update comment
                bool equal = false;
                string text = string.Empty;
                int idRow = -1, index = -1, startPos = -1, endPos = -1;

                Excel.Range xlRange = excel.xlWorkSheet.UsedRange;
                for (int currentRow = row; currentRow <= xlRange.Rows.Count; currentRow++)
                {
                    if (excel.xlWorkSheet.Cells[currentRow, "C"].Value2 == null)
                    {
                        continue;
                    }

                    // AbsOffActiveStatus (id=11130)   [Reprog, Delivery State, Reset To Delivery State]
                    text = excel.xlWorkSheet.Cells[currentRow, "C"].Value2.ToString();
                    if (text.IndexOf("(id=") > 0)
                    {
                        if (excel.xlWorkSheet.Cells[currentRow, "G"].Value2 == null)
                        {
                            error = "Error: id data at cell[" + currentRow.ToString() + "][G] is empty";
                            return false;
                        }

                        // Delete next row
                        idRow = currentRow++;
                        excel.xlWorkSheet.Rows[currentRow].Delete();

                        // Compare values
                        equal = true;
                        index = idRow;
                        while (excel.xlWorkSheet.Cells[index, "C"].Value2 != null && excel.xlWorkSheet.Cells[index, "C"].Value2.ToString() != string.Empty)
                        {
                            if (excel.xlWorkSheet.Cells[index, "C"].Value2.ToString() != excel.xlWorkSheet.Cells[index, "G"].Value2.ToString())
                            {
                                equal = false;
                                break;
                            }

                            index++;
                        }
                        currentRow = index;

                        // Update Usage column
                        if (equal || text == excel.xlWorkSheet.Cells[idRow, "G"].Value2.ToString() || text.Contains("[OEM_"))
                        {
                            startPos = text.Contains("[OEM_") ? text.IndexOf(',') + 2 : text.IndexOf('[');
                            endPos = text.IndexOf(']', startPos + 1);
                            if (endPos - startPos > 1)
                            {
                                if (endPos - startPos < 3)
                                {
                                    startPos = text.IndexOf('[', endPos + 1);
                                    endPos = text.IndexOf(']', startPos + 1);
                                }

                                if (endPos - startPos > 1)
                                {
                                    excel.xlWorkSheet.Cells[idRow, "K"] = text.Substring(startPos, endPos - startPos + 1);
                                    excel.xlWorkSheet.Cells[idRow, "C"] = text.Replace(excel.xlWorkSheet.Cells[idRow, "K"].Value2.ToString(), "");
                                    excel.xlWorkSheet.Cells[idRow, "G"] = text.Replace(excel.xlWorkSheet.Cells[idRow, "K"].Value2.ToString(), "");
                                }
                            }
                        }

                        if (equal)
                        {
                            excel.xlWorkSheet.Cells[idRow, "N"] = commentOk;
                        }
                        else
                        {
                            if (text.StartsWith("BBno") || text.StartsWith("CustomerID"))
                            {
                                excel.xlWorkSheet.Cells[idRow, "N"] = commentBBno;
                            }
                            else if (text.StartsWith("CustPartNo"))
                            {
                                excel.xlWorkSheet.Cells[idRow, "N"] = commentCustPartNo;
                            }
                            else if (text.StartsWith("EePlantBarcodeHU"))
                            {
                                excel.xlWorkSheet.Cells[idRow, "N"] = commentBarcodeHU;
                            }
                            else if (text.StartsWith("ProcessData") || text.StartsWith("ProgDate"))
                            {
                                excel.xlWorkSheet.Cells[idRow, "N"] = commentCSIS;
                            }
                            else
                            {
                                excel.xlWorkSheet.Cells[idRow, "N"] = "Tobe updated";
                            }
                            
                            excel.xlWorkSheet.Cells[idRow, "N"].Font.Color = ColorTranslator.ToOle(Color.Red);
                        }

                        excel.xlWorkSheet.Cells[idRow, "L"] = "OK";
                        excel.xlWorkSheet.Cells[idRow, "M"] = userName;
                    }
                }
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }

            return true;
        }
    }
}
