﻿using System;
using System.Configuration;
using RBLib;
using Excel = Microsoft.Office.Interop.Excel;
using System.Drawing;

namespace MyTool
{
    class DumpCheck : TaskBase
    {
        private string file = string.Empty;

        public DumpCheck() : base()
        {
        }

        public override int ValidateInputData(string taskNameList = "")
        {
            if (taskNameList == "" || !taskNameList.Contains(this.GetType().Name))
            {
                return 0;
            }

            string dataDir = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "OutputDir") + "\\data";
            string bbNumber = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "BBNumber");

            if (!IOMngr.Instance.CheckEEPROMdumpFile(dataDir, bbNumber, ref file))
            {
                return PrintError(file, "QG_EEPROM_Dump_Hint");
            }

            return 1;
        }

        public override int DoTask(string parentDir, string taskNameList = "")
        {
            if (taskNameList == "" || !taskNameList.Contains(this.GetType().Name))
            {
                return 0;
            }

            dir = parentDir;

            // Delete old Excel file
            string xlsFile = dir + "\\" + RBIO.GetFileName(file);
            if (RBIO.CheckFileExist(xlsFile))
            {
                if (!RBIO.DeleteFile(xlsFile))
                {
                    Logger.Instance.LogError(this.GetClassName() + " Delete old Excel file failed");
                    return -1;
                }
            }

            string error = string.Empty;
            string sheetName = ConfigurationManager.AppSettings["QG_EEPROM_Sheet_Name"];

            RBExcel excel = new RBExcel();

            // Open file Dump_check_12679BBNumber_00_CSW.xlsx
            Logger.Instance.LogInfo(this.GetClassName() + " Open file: " + file);
            if (!excel.Open(file, sheetName, ref error))
            {
                Logger.Instance.LogError(this.GetClassName() + " Create Excel file failed. " + error);
                return -1;
            }

            // Delete column
            Logger.Instance.LogInfo(this.GetClassName() + " Delete columns...");
            string[] columns = ConfigurationManager.AppSettings["QG_EEPROM_Dump_Delete_Columns"].Split(';');
            if (!RBExcelHelper.DeleteExcelColumns(excel, columns, ref error))
            {
                Logger.Instance.LogError(this.GetClassName() + " Delete Excel columns failed. " + error);
                return -1;
            }

            // Add columns (OK/NotOK, Rated by, Note)
            Logger.Instance.LogInfo(this.GetClassName() + " Add columns...");
            columns = ConfigurationManager.AppSettings["QG_EEPROM_Dump_Add_Columns"].Split(';');
            if (!RBExcelHelper.SetRowsValue(excel, 18, columns, ref error, 3))
            {
                Logger.Instance.LogError(this.GetClassName() + " Add Excel columns failed. " + error);
                return -1;
            }
            
            // Verify EEPROM file
            Logger.Instance.LogInfo(this.GetClassName() + " Verify EEPROM Dump Check file...");
            if (!VerifyEEPROMdumpFile(excel, 18, ref error))
            {
                Logger.Instance.LogError(this.GetClassName() + " Verify EEPROM file failed. " + error);
                return -1;
            }

            // Save file
            Logger.Instance.LogInfo(this.GetClassName() + " Save file...");
            if (!excel.SaveAs(xlsFile))
            {
                Logger.Instance.LogError(this.GetClassName() + " Save Excel file failed");
                return -1;
            }

            excel.Close();
            return 1;
        }
        
        private bool VerifyEEPROMdumpFile(RBExcel excel, int row, ref string error)
        {
            string userName = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "UserName");

            try
            {
                // Verify and update comment
                bool equal = false;
                string text = string.Empty;
                int idRow = -1, index = -1;

                Excel.Range xlRange = excel.xlWorkSheet.UsedRange;
                for (int currentRow = row; currentRow <= xlRange.Rows.Count; currentRow++)
                {
                    if (excel.xlWorkSheet.Cells[currentRow, "C"].Value2 == null)
                    {
                        continue;
                    }

                    // AbsOffActiveStatus (id=11130)   [Reprog, Delivery State, Reset To Delivery State]
                    text = excel.xlWorkSheet.Cells[currentRow, "C"].Value2.ToString();
                    if (text.IndexOf("(id=") > 0)
                    {
                        idRow = currentRow++;

                        // Compare values
                        equal = true;
                        index = idRow + 1;
                        while (excel.xlWorkSheet.Cells[index, "C"].Value2 != null && excel.xlWorkSheet.Cells[index, "C"].Value2.ToString() != string.Empty)
                        {
                            if (excel.xlWorkSheet.Cells[index, "C"].Value2.ToString() != excel.xlWorkSheet.Cells[index, "G"].Value2.ToString())
                            {
                                equal = false;
                                break;
                            }

                            index++;
                        }
                        currentRow = index;

                        if (equal)
                        {
                            excel.xlWorkSheet.Cells[idRow, "J"] = "OK";
                        }
                        else
                        {
                            excel.xlWorkSheet.Cells[idRow, "J"] = "Tobe updated";
                            excel.xlWorkSheet.Cells[idRow, "J"].Font.Color = ColorTranslator.ToOle(Color.Red);
                        }

                        excel.xlWorkSheet.Cells[idRow, "K"] = userName;
                    }
                }
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }

            return true;
        }
    }
}
