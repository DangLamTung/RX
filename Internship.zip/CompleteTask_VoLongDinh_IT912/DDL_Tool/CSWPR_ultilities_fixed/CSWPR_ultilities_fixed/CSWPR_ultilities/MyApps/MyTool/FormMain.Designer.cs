﻿namespace MyTool
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtConsole = new System.Windows.Forms.TextBox();
            this.btnReportAll = new System.Windows.Forms.Button();
            this.btnFuncSwitch = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnMemTrace = new System.Windows.Forms.Button();
            this.btnLCModel = new System.Windows.Forms.Button();
            this.btnErrorLog = new System.Windows.Forms.Button();
            this.btnErrata = new System.Windows.Forms.Button();
            this.btnEEPROM = new System.Windows.Forms.Button();
            this.btnLockedObjs = new System.Windows.Forms.Button();
            this.btnSwitch = new System.Windows.Forms.Button();
            this.btnQAC = new System.Windows.Forms.Button();
            this.btnDDL = new System.Windows.Forms.Button();
            this.btnRelease = new System.Windows.Forms.Button();
            this.btnDumpCheck = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtConsole
            // 
            this.txtConsole.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtConsole.BackColor = System.Drawing.SystemColors.WindowText;
            this.txtConsole.ForeColor = System.Drawing.SystemColors.Window;
            this.txtConsole.Location = new System.Drawing.Point(-1, 0);
            this.txtConsole.Multiline = true;
            this.txtConsole.Name = "txtConsole";
            this.txtConsole.ReadOnly = true;
            this.txtConsole.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtConsole.Size = new System.Drawing.Size(1301, 628);
            this.txtConsole.TabIndex = 0;
            // 
            // btnReportAll
            // 
            this.btnReportAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReportAll.Location = new System.Drawing.Point(6, 19);
            this.btnReportAll.Name = "btnReportAll";
            this.btnReportAll.Size = new System.Drawing.Size(75, 23);
            this.btnReportAll.TabIndex = 2;
            this.btnReportAll.Text = "Report All";
            this.btnReportAll.UseVisualStyleBackColor = true;
            this.btnReportAll.Click += new System.EventHandler(this.btnReportAll_Click);
            // 
            // btnFuncSwitch
            // 
            this.btnFuncSwitch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFuncSwitch.Location = new System.Drawing.Point(1399, 592);
            this.btnFuncSwitch.Name = "btnFuncSwitch";
            this.btnFuncSwitch.Size = new System.Drawing.Size(75, 23);
            this.btnFuncSwitch.TabIndex = 99;
            this.btnFuncSwitch.Text = "FuncSwitch";
            this.btnFuncSwitch.UseVisualStyleBackColor = true;
            this.btnFuncSwitch.Click += new System.EventHandler(this.btnFuncSwitch_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.btnMemTrace);
            this.groupBox1.Controls.Add(this.btnLCModel);
            this.groupBox1.Controls.Add(this.btnErrorLog);
            this.groupBox1.Controls.Add(this.btnErrata);
            this.groupBox1.Controls.Add(this.btnEEPROM);
            this.groupBox1.Controls.Add(this.btnLockedObjs);
            this.groupBox1.Controls.Add(this.btnSwitch);
            this.groupBox1.Controls.Add(this.btnQAC);
            this.groupBox1.Controls.Add(this.btnReportAll);
            this.groupBox1.Controls.Add(this.btnDDL);
            this.groupBox1.Location = new System.Drawing.Point(1306, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(168, 165);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "QG Reports";
            // 
            // btnMemTrace
            // 
            this.btnMemTrace.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMemTrace.Location = new System.Drawing.Point(87, 135);
            this.btnMemTrace.Name = "btnMemTrace";
            this.btnMemTrace.Size = new System.Drawing.Size(75, 23);
            this.btnMemTrace.TabIndex = 11;
            this.btnMemTrace.Text = "MemTrace";
            this.btnMemTrace.UseVisualStyleBackColor = true;
            this.btnMemTrace.Click += new System.EventHandler(this.btnMemTrace_Click);
            // 
            // btnLCModel
            // 
            this.btnLCModel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLCModel.Location = new System.Drawing.Point(87, 106);
            this.btnLCModel.Name = "btnLCModel";
            this.btnLCModel.Size = new System.Drawing.Size(75, 23);
            this.btnLCModel.TabIndex = 10;
            this.btnLCModel.Text = "LCModel";
            this.btnLCModel.UseVisualStyleBackColor = true;
            this.btnLCModel.Click += new System.EventHandler(this.btnLCModel_Click);
            // 
            // btnErrorLog
            // 
            this.btnErrorLog.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnErrorLog.Location = new System.Drawing.Point(87, 77);
            this.btnErrorLog.Name = "btnErrorLog";
            this.btnErrorLog.Size = new System.Drawing.Size(75, 23);
            this.btnErrorLog.TabIndex = 9;
            this.btnErrorLog.Text = "ErrorLog";
            this.btnErrorLog.UseVisualStyleBackColor = true;
            this.btnErrorLog.Click += new System.EventHandler(this.btnErrorLog_Click);
            // 
            // btnErrata
            // 
            this.btnErrata.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnErrata.Location = new System.Drawing.Point(87, 48);
            this.btnErrata.Name = "btnErrata";
            this.btnErrata.Size = new System.Drawing.Size(75, 23);
            this.btnErrata.TabIndex = 8;
            this.btnErrata.Text = "Errata";
            this.btnErrata.UseVisualStyleBackColor = true;
            this.btnErrata.Click += new System.EventHandler(this.btnErrata_Click);
            // 
            // btnEEPROM
            // 
            this.btnEEPROM.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEEPROM.Location = new System.Drawing.Point(6, 48);
            this.btnEEPROM.Name = "btnEEPROM";
            this.btnEEPROM.Size = new System.Drawing.Size(75, 23);
            this.btnEEPROM.TabIndex = 3;
            this.btnEEPROM.Text = "EEPROM";
            this.btnEEPROM.UseVisualStyleBackColor = true;
            this.btnEEPROM.Click += new System.EventHandler(this.btnEEPROM_Click);
            // 
            // btnLockedObjs
            // 
            this.btnLockedObjs.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLockedObjs.Location = new System.Drawing.Point(87, 19);
            this.btnLockedObjs.Name = "btnLockedObjs";
            this.btnLockedObjs.Size = new System.Drawing.Size(75, 23);
            this.btnLockedObjs.TabIndex = 7;
            this.btnLockedObjs.Text = "LockedObjs";
            this.btnLockedObjs.UseVisualStyleBackColor = true;
            this.btnLockedObjs.Click += new System.EventHandler(this.btnLockedObjs_Click);
            // 
            // btnSwitch
            // 
            this.btnSwitch.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSwitch.Location = new System.Drawing.Point(6, 135);
            this.btnSwitch.Name = "btnSwitch";
            this.btnSwitch.Size = new System.Drawing.Size(75, 23);
            this.btnSwitch.TabIndex = 6;
            this.btnSwitch.Text = "Switch";
            this.btnSwitch.UseVisualStyleBackColor = true;
            this.btnSwitch.Click += new System.EventHandler(this.btnSwitch_Click);
            // 
            // btnQAC
            // 
            this.btnQAC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnQAC.Location = new System.Drawing.Point(6, 106);
            this.btnQAC.Name = "btnQAC";
            this.btnQAC.Size = new System.Drawing.Size(75, 23);
            this.btnQAC.TabIndex = 5;
            this.btnQAC.Text = "QAC";
            this.btnQAC.UseVisualStyleBackColor = true;
            this.btnQAC.Click += new System.EventHandler(this.btnQAC_Click);
            // 
            // btnDDL
            // 
            this.btnDDL.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDDL.Location = new System.Drawing.Point(6, 77);
            this.btnDDL.Name = "btnDDL";
            this.btnDDL.Size = new System.Drawing.Size(75, 23);
            this.btnDDL.TabIndex = 4;
            this.btnDDL.Text = "DDL";
            this.btnDDL.UseVisualStyleBackColor = true;
            this.btnDDL.Click += new System.EventHandler(this.btnDDL_Click);
            // 
            // btnRelease
            // 
            this.btnRelease.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRelease.Location = new System.Drawing.Point(1399, 563);
            this.btnRelease.Name = "btnRelease";
            this.btnRelease.Size = new System.Drawing.Size(75, 23);
            this.btnRelease.TabIndex = 98;
            this.btnRelease.Text = "Release";
            this.btnRelease.UseVisualStyleBackColor = true;
            this.btnRelease.Click += new System.EventHandler(this.btnRelease_Click);
            // 
            // btnDumpCheck
            // 
            this.btnDumpCheck.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDumpCheck.Location = new System.Drawing.Point(1399, 534);
            this.btnDumpCheck.Name = "btnDumpCheck";
            this.btnDumpCheck.Size = new System.Drawing.Size(75, 23);
            this.btnDumpCheck.TabIndex = 97;
            this.btnDumpCheck.Text = "DumpCheck";
            this.btnDumpCheck.UseVisualStyleBackColor = true;
            this.btnDumpCheck.Click += new System.EventHandler(this.btnDumpCheck_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1486, 627);
            this.Controls.Add(this.btnDumpCheck);
            this.Controls.Add(this.btnRelease);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnFuncSwitch);
            this.Controls.Add(this.txtConsole);
            this.Name = "FormMain";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtConsole;
        private System.Windows.Forms.Button btnReportAll;
        private System.Windows.Forms.Button btnFuncSwitch;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnDDL;
        private System.Windows.Forms.Button btnLockedObjs;
        private System.Windows.Forms.Button btnSwitch;
        private System.Windows.Forms.Button btnQAC;
        private System.Windows.Forms.Button btnEEPROM;
        private System.Windows.Forms.Button btnErrorLog;
        private System.Windows.Forms.Button btnErrata;
        private System.Windows.Forms.Button btnMemTrace;
        private System.Windows.Forms.Button btnLCModel;
        private System.Windows.Forms.Button btnRelease;
        private System.Windows.Forms.Button btnDumpCheck;
    }
}

