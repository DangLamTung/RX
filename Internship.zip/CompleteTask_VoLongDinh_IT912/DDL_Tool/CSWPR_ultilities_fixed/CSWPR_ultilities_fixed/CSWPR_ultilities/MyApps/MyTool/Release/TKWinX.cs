﻿using RBLib;

namespace MyTool
{
    class TKWinX : TaskBase
    {
        private string file = string.Empty;

        public TKWinX() : base()
        {
        }

        public override int ValidateInputData(string taskNameList = "")
        {
            if (!IsMyTask(taskNameList))
            {
                return 0;
            }

            string dataDir = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "OutputDir") + "\\data";
            string bbNumber = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "BBNumber");

            if (!IOMngr.Instance.CheckTKWinXFile(dataDir, bbNumber, ref file))
            {
                return PrintError(file, "Release_TK_WinX_Hint");
            }

            return 1;
        }

        public override int DoTask(string parentDir, string taskNameList = "")
        {
            if (!IsMyTask(taskNameList))
            {
                return 0;
            }

            if (!CreateDir(parentDir, "Release_TK_WinX_Dir"))
            {
                return -1;
            }

            // Copy file
            if (CopyFileWithInfo(dir, file) < 1)
            {
                return -1;
            }

            return 1;
        }
    }
}
