﻿using System.Collections.Generic;

namespace MyTool
{
    public class Release : TaskBase
    {
        private List<TaskBase> workers = null;

        public Release() : base()
        {
            workers = new List<TaskBase>();
            workers.Add(new AppContainer());
            workers.Add(new CSWHEX());
            workers.Add(new FWL());
            workers.Add(new ODX());
            workers.Add(new Prokist());
            workers.Add(new ReleaseEEPROM());
            workers.Add(new ReleaseLCModel());
            workers.Add(new SDP());
            workers.Add(new TKWinX());
        }

        public override int ValidateInputData(string taskNameList = "")
        {
            int res = 0;
            foreach (TaskBase worker in workers)
            {
                res = worker.ValidateInputData(taskNameList);
                if (res < 0)
                {
                    Logger.Instance.LogError(worker.GetClassName() + " Checking input data...FAILED");
                    return res;
                }
                else if (res > 0)
                {
                    Logger.Instance.LogInfo(worker.GetClassName() + " Checking input data...OK");
                }
            }

            return res;
        }

        public override int DoTask(string parentDir, string taskNameList = "")
        {
            if (!CreateDir(parentDir, "Release_Dir"))
            {
                return -1;
            }
            Logger.Instance.LogInfo(this.GetClassName() + " Do task...OK\r\n");

            int res = 0;
            foreach (TaskBase worker in workers)
            {
                res = worker.DoTask(dir, taskNameList);
                if (res < 0)
                {
                    Logger.Instance.LogError(worker.GetClassName() + " Do task...FAILED");
                    return res;
                }
                else if (res > 0)
                {
                    Logger.Instance.LogInfo(worker.GetClassName() + " Do task...OK\r\n");
                }
            }

            return res;
        }
    }
}
