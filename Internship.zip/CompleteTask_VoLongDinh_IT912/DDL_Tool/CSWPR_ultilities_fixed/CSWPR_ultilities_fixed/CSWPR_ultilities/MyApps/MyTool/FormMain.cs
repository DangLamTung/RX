﻿using System;
using System.Windows.Forms;
using RBLib;

namespace MyTool
{
    public partial class FormMain : Form
    {
        private QG qg = null;
        private Release rl = null;
        private FuncSwitch fs = null;

        #region Form Events

        public FormMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            this.Text = "My Tools";
            Logger.Instance.SetFormMain(this);

            qg = new QG();
            rl = new Release();
            fs = new FuncSwitch();
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Are you sure ???", this.Text, MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                e.Cancel = true;
            }
        }

        #region QG

        private void btnReportAll_Click(object sender, EventArgs e)
        {
            PerformQGTask();
        }

        private void btnEEPROM_Click(object sender, EventArgs e)
        {
            PerformQGTask("EEPROM");
        }

        private void btnDDL_Click(object sender, EventArgs e)
        {
            PerformQGTask("DDL");
        }

        private void btnQAC_Click(object sender, EventArgs e)
        {
            PerformQGTask("QAC");
        }

        private void btnSwitch_Click(object sender, EventArgs e)
        {
            PerformQGTask("Switch");
        }

        private void btnLockedObjs_Click(object sender, EventArgs e)
        {
            PerformQGTask("LockedObjects");
        }

        private void btnErrata_Click(object sender, EventArgs e)
        {
            PerformQGTask("Errata");
        }

        private void btnErrorLog_Click(object sender, EventArgs e)
        {
            PerformQGTask("ErrorLog");
        }

        private void btnLCModel_Click(object sender, EventArgs e)
        {
            PerformQGTask("LCModel");
        }

        private void btnMemTrace_Click(object sender, EventArgs e)
        {
            PerformQGTask("MemTrace");
        }

        #endregion

        private void btnDumpCheck_Click(object sender, EventArgs e)
        {
            PerformQGTask("DumpCheck");
        }

        private void btnRelease_Click(object sender, EventArgs e)
        {
            PerformReleaseTask();
        }

        private void btnFuncSwitch_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            // Validating input data
            this.WriteConsole("------------------------------------------------------------------------------------------------------------------------");
            this.WriteConsole("Validating input data...\r\n");
            if (fs.ValidateInputData() < 1)
            {
                goto __end;
            }
            this.WriteConsole("\r\nValidating input data...DONE");
            
            // Do tasks
            this.WriteConsole("------------------------------------------------------------------------------------------------------------------------");
            this.WriteConsole("Getting FuncSwitch values...\r\n");
            if (fs.DoTask() < 1)
            {
                goto __end;
            }
            this.WriteConsole("\r\nGetting FuncSwitch values...DONE");
            
        __end:
            Cursor.Current = Cursors.Default;
        }

        #endregion

        #region Support Functions

        private bool IsConfigEmpty(string section, string key, ref string value)
        {
            string tmp = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), section, key);
            if (tmp.Equals(""))
            {
                return true;
            }
            else
            {
                value = tmp;
                return false;
            }
        }

        private bool ValidateGeneralConfig()
        {
            string section = "General";
            string value = string.Empty;

            // Checking output directory
            string dir = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), section, "OutputDir");
            if (!RBIO.CheckDirExist(dir))
            {
                Logger.Instance.LogError("Checking output directory...FAILED => Directory not found: " + dir + ". Update the Config.ini file");
                return false;
            }
            this.WriteConsole("Checking output directory...OK => " + dir);

            // Checking data directory
            dir += "\\data";
            if (!RBIO.CheckDirExist(dir))
            {
                Logger.Instance.LogError("Checking data directory...FAILED => Directory not found: " + dir + ". Update the Config.ini file");
                return false;
            }
            this.WriteConsole("Checking data directory...OK => " + dir);

            // Checking BBNumber
            if (this.IsConfigEmpty(section, "BBNumber", ref value))
            {
                Logger.Instance.LogError("Checking BBNumber...FAILED => BBNumber is empty. Update the Config.ini file");
                return false;
            }
            this.WriteConsole("Checking BBNumber...OK => " + value);

            return true;
        }

        private bool ValidateQGConfig()
        {
            string section = "General";
            string value = string.Empty;
            
            if (!this.ValidateGeneralConfig())
            {
                return false;
            }

            // Checking CSCRM
            if (this.IsConfigEmpty(section, "CSCRM", ref value))
            {
                Logger.Instance.LogError("Checking CSCRM...FAILED => CSCRM is empty. Update the Config.ini file");
                return false;
            }
            this.WriteConsole("Checking CSCRM...OK => " + value);

            // Checking CSIS
            if (this.IsConfigEmpty(section, "CSIS", ref value))
            {
                Logger.Instance.LogError("Checking CSIS...FAILED => CSIS is empty. Update the Config.ini file");
                return false;
            }
            this.WriteConsole("Checking CSIS...OK => " + value);

            // Checking ProjectName
            if (this.IsConfigEmpty(section, "ProjectName", ref value))
            {
                Logger.Instance.LogError("Checking ProjectName...FAILED => ProjectName is empty. Update the Config.ini file");
                return false;
            }
            this.WriteConsole("Checking ProjectName...OK => " + value);

            // Checking UserName
            if (this.IsConfigEmpty(section, "UserName", ref value))
            {
                this.WriteConsole("Checking UserName...FAILED => UserName is empty. Update the Config.ini file");
                return false;
            }
            this.WriteConsole("Checking UserName...OK => " + value);
            
            return true;
        }

        private void PerformQGTask(string taskNameList = "")
        {
            Cursor.Current = Cursors.WaitCursor;
            
            // Validating general data
            this.WriteConsole("------------------------------------------------------------------------------------------------------------------------");
            this.WriteConsole("Validating QG config...\r\n");
            if (!this.ValidateQGConfig())
            {
                goto __end;
            }
            this.WriteConsole("\r\nValidating QG config...DONE");

            // Validating input data
            this.WriteConsole("------------------------------------------------------------------------------------------------------------------------");
            this.WriteConsole("Validating input data...");
            if (qg.ValidateInputData(taskNameList) < 0)
            {
                goto __end;
            }
            this.WriteConsole("\r\nValidating input data...DONE");

            // Perform QG task
            this.WriteConsole("------------------------------------------------------------------------------------------------------------------------");
            this.WriteConsole("Perform QG task...\r\n");
            if (qg.DoTask(RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "OutputDir"), taskNameList) < 0)
            {
                goto __end;
            }
            this.WriteConsole("Perform QG task...DONE");

        __end:
            Cursor.Current = Cursors.Default;
        }

        private void PerformReleaseTask(string taskNameList = "")
        {
            Cursor.Current = Cursors.WaitCursor;

            // Validating general data
            this.WriteConsole("------------------------------------------------------------------------------------------------------------------------");
            this.WriteConsole("Validating Release config...\r\n");
            if (!this.ValidateGeneralConfig())
            {
                goto __end;
            }
            this.WriteConsole("\r\nValidating Release config...DONE");

            // Validating input data
            this.WriteConsole("------------------------------------------------------------------------------------------------------------------------");
            this.WriteConsole("Validating input data...");
            if (rl.ValidateInputData(taskNameList) < 0)
            {
                goto __end;
            }
            this.WriteConsole("\r\nValidating input data...DONE");

            // Perform Release task
            this.WriteConsole("------------------------------------------------------------------------------------------------------------------------");
            this.WriteConsole("Perform Release task...\r\n");
            if (rl.DoTask(RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "OutputDir"), taskNameList) < 0)
            {
                goto __end;
            }
            this.WriteConsole("Perform Release task...DONE");

        __end:
            Cursor.Current = Cursors.Default;
        }

        #endregion

        #region Console

        public void WriteConsole(string message)
        {
            if (txtConsole.Text == string.Empty)
            {
                txtConsole.Text = message;
            }
            else
            {
                txtConsole.Text += "\r\n" + message;
            }

            txtConsole.SelectionStart = txtConsole.Text.Length;
            txtConsole.ScrollToCaret();
        }

        #endregion
    }
}
