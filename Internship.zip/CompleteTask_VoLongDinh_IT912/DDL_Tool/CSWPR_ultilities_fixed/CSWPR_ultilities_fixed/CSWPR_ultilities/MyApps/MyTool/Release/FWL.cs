﻿using RBLib;

namespace MyTool
{
    class FWL : TaskBase
    {
        private string file = string.Empty;

        public FWL() : base()
        {
        }

        public override int ValidateInputData(string taskNameList = "")
        {
            if (!IsMyTask(taskNameList))
            {
                return 0;
            }

            string dataDir = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "OutputDir") + "\\data";
            string bbNumber = RBIni.ReadString(IOMngr.Instance.GetConfigFile(), "General", "BBNumber");

            if (!IOMngr.Instance.CheckFWLFile(dataDir, bbNumber, ref file))
            {
                return PrintError(file, "Release_FWL_Hint");
            }

            return 1;
        }

        public override int DoTask(string parentDir, string taskNameList = "")
        {
            if (!IsMyTask(taskNameList))
            {
                return 0;
            }

            if (!CreateDir(parentDir, "Release_FWL_Dir"))
            {
                return -1;
            }

            // Copy file
            if (CopyFileWithInfo(dir, file) < 1)
            {
                return -1;
            }

            return 1;
        }
    }
}
