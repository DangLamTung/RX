﻿using System;
using System.IO;

namespace RBLib
{
    public class RBIO
    {
        #region Directory

        public static bool CheckDirExist(string dir)
        {
            return Directory.Exists(dir);
        }

        public static bool CreateDir(string dir)
        {
            try
            {
                Directory.CreateDirectory(dir);
            }
            catch (Exception ex)
            {
                string error = ex.Message;
                return false;
            }

            return true;
        }

        public static string[] GetFiles(string dir, string searchPattern = "")
        {
            try
            {
                if (searchPattern == "")
                {
                    return Directory.GetFiles(dir);
                }
                else
                {
                    return Directory.GetFiles(dir, searchPattern);
                }
            }
            catch (Exception ex)
            {
                string error = ex.Message;
                return null;
            }
        }

        public static string[] GetDirectories(string dir)
        {
            try
            {
                return Directory.GetDirectories(dir);
            }
            catch (Exception ex)
            {
                string error = ex.Message;
                return null;
            }
        }

        #endregion

        #region File

        public static bool CheckFileExist(string file)
        {
            return File.Exists(file);
        }

        public static bool DeleteFile(string file)
        {
            try
            {
                File.Delete(file);
            }
            catch (Exception ex)
            {
                string error = ex.Message;
                return false;
            }

            return true;
        }

        public static bool CopyFile(string file, string dir)
        {
            try
            {
                File.Copy(file, dir + "\\" + GetFileName(file), true);
            }
            catch (Exception ex)
            {
                string error = ex.Message;
                return false;
            }
            
            return true;
        }

        public static string GetFileName(string file)
        {
            return Path.GetFileName(file);
        }

        public static string GetFileTitle(string file)
        {
            return Path.GetFileName(file).Replace(Path.GetExtension(file), "");
        }

        #endregion
    }
}
