﻿using System;
using System.IO;

using System.Drawing;


namespace RBLib

{
    public class RBExcelHelper
    {
        public static bool TransferData(string file, string delimiter, RBExcel excel, ref string error)
        {
            bool res = true;
            StreamReader reader = null;

            try
            {
                int row = 1, column = 1;
                string line = string.Empty;
                reader = new StreamReader(file);

                while ((line = reader.ReadLine()) != null)
                {
                    if (line != string.Empty)
                    {
                        string[] arr = line.Split(new string[] { delimiter }, StringSplitOptions.None);
                        for (column = 1; column <= arr.Length; column++)
                        {
                            excel.xlWorkSheet.Cells[row, column] = arr[column - 1].Trim();
                        }
                    }

                    row++;
                }
            }
            catch (Exception ex)
            {
                error = ex.Message;
                res = false;
            }
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                }
            }

            return res;
        }

        public static bool HideExcelColumns(RBExcel excel, string[] columns, ref string error)
        {
            bool res = true;

            try
            {
                for (int i = 0; i < columns.Length; i++)
                {
                    excel.xlWorkSheet.Columns[columns[i]].Hidden = true;
                }
            }
            catch (Exception ex)
            {
                error = ex.Message;
                res = false;
            }

            return res;
        }

        public static bool DeleteExcelColumns(RBExcel excel, string[] columns, ref string error)
        {
            bool res = true;

            try
            {
                for (int i = 0; i < columns.Length; i++)
                {
                    excel.xlWorkSheet.Columns[columns[i]].Delete();
                }
            }
            catch (Exception ex)
            {
                error = ex.Message;
                res = false;
            }

            return res;
        }

        public static bool FreezeExcelRow(RBExcel excel, string[] rows, ref string error)
        {
            bool res = true;

            try
            {
                // Freeze first row
                excel.xlWorkSheet.Activate();
                excel.xlWorkSheet.Application.ActiveWindow.SplitRow = 1;
                excel.xlWorkSheet.Application.ActiveWindow.FreezePanes = true;
               

              
            }
            catch (Exception ex)
            {
                error = ex.Message;
                res = false;
            }

            return res;
        }

        
       
        public static bool EnableFilter(RBExcel excel, string[] columns, ref string error)
        {
            bool res = true;

            try
            {
                // Enable filter First Row
                excel.xlWorkSheet.EnableAutoFilter = true;
                excel.xlWorkSheet.Cells.AutoFilter(1);
            }
            catch (Exception ex)
            {
                error = ex.Message;
                res = false;
            }

            return res;
        }


        public static bool BolderText(RBExcel excel, string[] columns, ref string error)
        {
            bool res = true;

            try
            {
                // Bolder text in the first row
                excel.xlWorkSheet.Range["A1", "A1"].EntireRow.Font.Bold = true;

                //Color text (Red)
                excel.xlWorkSheet.Range["A1", "A1"].EntireRow.Font.Color = Color.Red;

                // Theme color 
                excel.xlWorkSheet.Range["A1", "A1"].EntireRow.Interior.Color = Color.Yellow;

            }
            catch (Exception ex)
            {
                error = ex.Message;
                res = false;
            }

            return res;
        }


        
        public static bool AutoFitColumns(RBExcel excel, string[] columns, ref string error)
        {
            bool res = true;

            try
            {
                // AutoFitColumns
                excel.xlWorkSheet.Range["A1", "A1"].EntireRow.Columns.AutoFit()   ;
                   
            
            }
            catch (Exception ex)
            {
                error = ex.Message;
                res = false;
            }

            return res;
        }

       
        public static bool SetRowsValue(RBExcel excel, int row, string[] values, ref string error, int baseColumn = -1)
        {
            bool res = true;

            try
            {
                string[] arr = null;
                for (int i = 0; i < values.Length; i++)
                {
                    arr = values[i].Split('=');
                    if (arr.Length != 2)
                    {
                        error = "Wrong value format. Check setting file. (Ex: Column=Value)";
                        res = false;
                        break;
                    }
                    else
                    {
                        excel.xlWorkSheet.Cells[row, arr[0]] = arr[1];

                        if (baseColumn > -1)
                        {
                            excel.xlWorkSheet.Cells[row, arr[0]].Font.Bold = excel.xlWorkSheet.Cells[row, baseColumn].Font.Bold;
                            excel.xlWorkSheet.Cells[row, arr[0]].Interior.Color = excel.xlWorkSheet.Cells[row, baseColumn].Interior.Color;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                error = ex.Message;
                res = false;
            }

            return res;
        }
    }
}

