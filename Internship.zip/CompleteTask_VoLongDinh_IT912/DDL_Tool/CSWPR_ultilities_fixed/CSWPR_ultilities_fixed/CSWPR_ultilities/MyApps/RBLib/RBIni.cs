﻿using System.Text;
using System.Runtime.InteropServices;

namespace RBLib
{
    public class RBIni
    {
        [DllImport("kernel32", CharSet = CharSet.Auto)]
        public static extern int GetPrivateProfileString(string section, string key, string defaultValue, StringBuilder retValue, int size, string file);

        [DllImport("kernel32", CharSet = CharSet.Auto)]
        public static extern long WritePrivateProfileString(string section, string key, string value, string file);

        public static string ReadString(string file, string section, string key, string defaultValue = "")
        {
            StringBuilder retValue = new StringBuilder(255);
            int res = GetPrivateProfileString(section, key, defaultValue, retValue, 255, file);
            return retValue.ToString();
        }

        public static bool WriteString(string file, string section, string key, string value)
        {
            return WritePrivateProfileString(section, key, value, file) > 0;
        }
    }
}
